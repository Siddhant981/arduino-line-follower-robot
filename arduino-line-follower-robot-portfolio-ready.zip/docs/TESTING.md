# Testing & Debugging

## Recommended sequence

### 1. Sensor test
Verify each sensor responds correctly over the line and background.

Check sensor orientation, height, track contrast, wiring, and threshold.

### 2. Motor test
Test left and right motors independently.

Check direction, relative speed, alignment, wheels, and driver wiring.

### 3. Low-speed track test
Start on a simple straight section and verify line detection and steering direction.

### 4. Turn test
Use progressively sharper turns. If the robot overshoots, check turn PWM, sensor height, wheel alignment, and motor mismatch.

### 5. Surface test
Different surfaces can change reflectance, traction, motor load, and steering response.

## Debugging rule

```text
Reproduce
   ↓
Measure
   ↓
Isolate one variable
   ↓
Change one thing
   ↓
Test again
   ↓
Document the result
```

Avoid changing threshold, PWM, wiring, and mechanical alignment simultaneously.

## Known limitations

- No automatic sensor calibration
- No PID control
- No encoder feedback
- No wheel-speed measurement
- No automatic parameter tuning
