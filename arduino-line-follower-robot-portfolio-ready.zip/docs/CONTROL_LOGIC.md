# Control Logic

The robot uses an eight-channel reflectance array and threshold-based rules.

```text
Sensor readings
      ↓
Compare with threshold
      ↓
Identify line region
      ↓
Choose motion state
      ↓
Set motor direction + PWM
```

| Sensor region | Action |
|---|---|
| S5–S8 | Turn left |
| S4 | Forward |
| S1–S3 | Turn right |

The TB6612FNG receives motor direction signals plus PWM speed commands.

## Why this is not PID

The current implementation does not calculate a continuous position error and does not use proportional, integral, or derivative gains. It is intentionally a simple rule-based controller.

A future PID version could calculate a weighted line position, compare it with the center position, and continuously adjust left/right motor speeds.

## Main tuning parameters

- `SENSOR_THRESHOLD`
- Forward PWM
- Left-turn PWM
- Right-turn PWM
- Sensor-to-track distance
- Mechanical wheel alignment
