/*
 * Arduino Line Follower Robot
 * Arduino Nano + QTR-8RC + TB6612FNG
 *
 * Control: threshold-based rules with fixed PWM values.
 */

const uint8_t AIN1 = 7;
const uint8_t AIN2 = 4;
const uint8_t BIN1 = 8;
const uint8_t BIN2 = 9;
const uint8_t PWMA = 5;
const uint8_t PWMB = 6;
const uint8_t STBY = 12;
const uint8_t LED_PIN = 2;

const uint8_t S1 = A0;
const uint8_t S2 = A1;
const uint8_t S3 = A2;
const uint8_t S4 = A3;
const uint8_t S5 = A4;
const uint8_t S6 = A5;
const uint8_t S7 = A6;
const uint8_t S8 = A7;

const int SENSOR_THRESHOLD = 900;

void setup() {
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  pinMode(STBY, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(STBY, HIGH);
  delay(5000);
}

void moveForward() {
  analogWrite(PWMA, 237);
  analogWrite(PWMB, 237);
  digitalWrite(AIN1, HIGH);
  digitalWrite(AIN2, LOW);
  digitalWrite(BIN1, HIGH);
  digitalWrite(BIN2, LOW);
}

void turnLeft() {
  analogWrite(PWMA, 233);
  analogWrite(PWMB, 125);
  digitalWrite(AIN1, HIGH);
  digitalWrite(AIN2, LOW);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, HIGH);
}

void turnRight() {
  analogWrite(PWMA, 224);
  analogWrite(PWMB, 144);
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, HIGH);
  digitalWrite(BIN1, HIGH);
  digitalWrite(BIN2, LOW);
}

void loop() {
  const int s1 = analogRead(S1);
  const int s2 = analogRead(S2);
  const int s3 = analogRead(S3);
  const int s4 = analogRead(S4);
  const int s5 = analogRead(S5);
  const int s6 = analogRead(S6);
  const int s7 = analogRead(S7);
  const int s8 = analogRead(S8);

  const bool allSensorsActive =
    s1 > SENSOR_THRESHOLD && s2 > SENSOR_THRESHOLD &&
    s3 > SENSOR_THRESHOLD && s4 > SENSOR_THRESHOLD &&
    s5 > SENSOR_THRESHOLD && s6 > SENSOR_THRESHOLD &&
    s7 > SENSOR_THRESHOLD && s8 > SENSOR_THRESHOLD;

  digitalWrite(LED_PIN, allSensorsActive ? HIGH : LOW);

  if (s5 > SENSOR_THRESHOLD || s6 > SENSOR_THRESHOLD ||
      s7 > SENSOR_THRESHOLD || s8 > SENSOR_THRESHOLD) {
    turnLeft();
  } else if (s4 > SENSOR_THRESHOLD) {
    moveForward();
  } else if (s1 > SENSOR_THRESHOLD || s2 > SENSOR_THRESHOLD ||
             s3 > SENSOR_THRESHOLD) {
    turnRight();
  }
}
