# Arduino Line Follower Robot

A compact autonomous line-following robot built around an **Arduino Nano**, **QTR-8RC 8-channel line sensor array**, and **TB6612FNG dual motor driver**.

This project demonstrates practical robotics fundamentals: threshold-based line detection, differential motor control, PWM speed control, and hardware/software debugging.

![Line follower robot](./line%20following%20robot.jpeg)

## Hardware

| Component | Specification / Role |
|---|---|
| Microcontroller | Arduino Nano |
| Line sensor | QTR-8RC, 8-channel reflectance sensor |
| Motor driver | TB6612FNG |
| Motors | DC geared motors, approximately 200–300 RPM |
| Battery | 2S 7.4 V LiPo |
| Power | Voltage regulator |

![Robot close-up](./robot%20closeup.jpeg)

## Pin Configuration

### TB6612FNG

| Signal | Arduino Nano |
|---|---:|
| PWMA | D5 |
| AIN1 | D7 |
| AIN2 | D4 |
| PWMB | D6 |
| BIN1 | D8 |
| BIN2 | D9 |
| STBY | D12 |

### QTR-8RC

| Sensor | Arduino Nano |
|---|---:|
| S1 | A0 |
| S2 | A1 |
| S3 | A2 |
| S4 | A3 |
| S5 | A4 |
| S6 | A5 |
| S7 | A6 |
| S8 | A7 |

LED indicator: **D2**

## How It Works

1. Read all eight sensor values.
2. Compare readings with a configured threshold.
3. Determine the detected line region.
4. Select a motion state.
5. Apply motor direction and PWM.
6. Repeat continuously.

The current implementation uses **rule-based control**, not PID or encoder feedback.

| Sensor region | Action |
|---|---|
| S5–S8 | Turn left |
| S4 | Forward |
| S1–S3 | Turn right |

## Software

- Arduino IDE
- Arduino C/C++
- `analogRead()` for sensor acquisition
- `analogWrite()` for PWM motor control
- Digital GPIO for motor direction and standby control

No external libraries are required by the current sketch.

## Testing & Debugging

Important tuning variables:

- Sensor-to-track distance
- Sensor threshold
- Motor PWM values
- Wheel alignment
- Left/right motor speed mismatch
- Track surface and line/background contrast

For troubleshooting, change **one variable at a time** and verify the result.

See [docs/TESTING.md](./docs/TESTING.md) and [docs/CONTROL_LOGIC.md](./docs/CONTROL_LOGIC.md).

## Limitations

- Fixed sensor threshold
- Fixed steering PWM values
- No PID controller
- No encoder feedback
- No closed-loop wheel-speed control
- Track-dependent tuning

## Future Improvements

- Startup sensor calibration
- Weighted sensor-position calculation
- PID line-following control
- Wheel encoders and odometry
- Configurable parameters
- Serial diagnostics
- Better line-loss and intersection handling

## Learning Outcomes

**Arduino → sensors → motor driver → PWM → differential drive → debugging → autonomous control**

The project demonstrates that reliable robot behavior depends on the interaction between software, electronics, mechanics, and the physical environment.

## Author

**Siddhant Hirave**

Computer Engineering student interested in robotics, embedded systems, automation, and autonomous systems.

- GitHub: [@Siddhant981](https://github.com/Siddhant981)
- Portfolio: [Siddhant's Portfolio](https://siddhant981.github.io/Portfolio/)

## License

No open-source license has been added. Until a license is added, reuse and redistribution should not be assumed to be permitted.
